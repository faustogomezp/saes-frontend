import { Dialog, DialogTitle, DialogActions, Button } from '@mui/material';
import { resetPassword } from './usuarios.api';

export default function ResetPasswordDialog({ userId, onClose }) {
  if (!userId) return null;

  const handleReset = async () => {
    await resetPassword(userId);
    onClose();
  };

  return (
    <Dialog open onClose={onClose}>
      <DialogTitle>
        ¿Resetear contraseña del usuario?
      </DialogTitle>

      <DialogActions>
        <Button onClick={onClose}>Cancelar</Button>
        <Button color="error" onClick={handleReset}>
          Confirmar
        </Button>
      </DialogActions>
    </Dialog>
  );
}