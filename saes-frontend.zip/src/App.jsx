import { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './auth/Login';
import SaesList from './saes/SaesList';
import UsuariosList from './usuarios/UsuariosList';
import DashboardSaes from './pages/DashboardSaes';
import AppLayout from './layout/AppLayout';

function App() {
  const [logged, setLogged] = useState(!!localStorage.getItem('token'));
  const user = JSON.parse(localStorage.getItem('user'));

  const handleLogin = () => {
    setLogged(true);
  };

  const handleLogout = () => {
    localStorage.clear();
    setLogged(false);
  };

  return (
    <BrowserRouter>
      {!logged ? (
        <Routes>
          <Route path="*" element={<Login onLogin={handleLogin} />} />
        </Routes>
      ) : (
        <AppLayout user={user} onLogout={handleLogout}>
          <Routes>
            {user.rol !== 'TECNICO' && (
              <Route path="/dashboard" element={<DashboardSaes />} />
            )}

            <Route
              path="*"
              element={
                <Navigate
                  to={user.rol !== 'TECNICO' ? '/dashboard'  : '/saes'}
                />
              }
            />
            <Route path="/saes" element={<SaesList user={user} />} />

            <Route path="/usuarios" element={<UsuariosList user={user }/>} />;

          </Routes>
        </AppLayout>
      )}
    </BrowserRouter>
  );
}

export default App;